import { test } from '@playwright/test';
import { TEST_CREDENTIALS } from '../config/test-credentials';
import { Logger } from '../utils/logger';
import { TestContext } from '../utils/test-context';
import { generateAlphaNumericId, generateStepProductName, generateCustomerEmail, getLastRunState } from '../utils/test-data';
import { LoginPage } from '../pages/LoginPage';
import { ProductsPage, ProductConfig } from '../pages/ProductsPage';
import { FunnelBuilderPage } from '../pages/FunnelBuilderPage';
import { SalesPage } from '../pages/SalesPage';
import { PaymentPage } from '../pages/PaymentPage';

test('Resume From Product Flow & Live Purchase (Using Old/Latest Project)', async ({ page }) => {
  const context = new TestContext('regular');

  // Automatically read previous run state, or fall back to picking newest project in dropdown
  const savedState = getLastRunState();
  const baseRandom = savedState?.baseRandom || generateAlphaNumericId(6);
  const projectName = savedState?.projectName || ''; 

  context.projectName = projectName;
  context.customerEmail = generateCustomerEmail();

  // Clean alphanumeric naming without hyphens: "QA <random> <STEP>"
  const products: ProductConfig[] = [
    { key: 'FE', productName: generateStepProductName(baseRandom, 'FE'), salesPageName: 'FE Sales', checkoutPageName: 'FE Checkout', price: '100' },
    { key: 'OTO1', productName: generateStepProductName(baseRandom, 'OTO1'), salesPageName: 'OTO1 Sales', checkoutPageName: 'OTO1 Checkout', price: '100' },
    { key: 'DS1', productName: generateStepProductName(baseRandom, 'DS1'), salesPageName: 'DS1 Sales', checkoutPageName: 'DS1 Checkout', price: '100' },
    { key: 'OTO2', productName: generateStepProductName(baseRandom, 'OTO2'), salesPageName: 'OTO2 Sales', checkoutPageName: 'OTO2 Checkout', price: '100' },
    { key: 'DS2', productName: generateStepProductName(baseRandom, 'DS2'), salesPageName: 'DS2 Sales', checkoutPageName: 'DS2 Checkout', price: '100' },
  ];

  Logger.info('START', `========================================================`);
  Logger.info('START', `Resuming Product Flow for Project: "${projectName || 'LATEST'}"`);
  Logger.info('START', `Products format: "QA ${baseRandom} <STEP>" (No hyphens)`);
  Logger.info('START', `========================================================`);

  const loginPage = new LoginPage(page, context);
  const productsPage = new ProductsPage(page, context);
  const funnelBuilderPage = new FunnelBuilderPage(page, context);
  const salesPage = new SalesPage(page, context);
  const paymentPage = new PaymentPage(page, context);

  // 1. Login
  await loginPage.openLogin();
  await loginPage.login(TEST_CREDENTIALS.email, TEST_CREDENTIALS.password);

  // 2. Open Products directly and create each product (Reuses existing project)
  await productsPage.openProducts();
  for (const prod of products) {
    await productsPage.createProduct(prod.productName, prod.price);
    await productsPage.connectProductPages(prod.productName, projectName, prod.salesPageName, prod.checkoutPageName);
    await productsPage.openProducts(); // Ready for next product
  }

  // 3. Build Funnel Pipeline and wire CTA
  await funnelBuilderPage.createFunnel(`QA ${baseRandom} Funnel`, false, products[0].productName);
  await funnelBuilderPage.wireSalesPageToFunnel();

  // 4. Live Purchase Run
  const liveSalesPage = await salesPage.openLiveSalesPage();
  try {
    await paymentPage.openBuyerJourney(liveSalesPage);
    await paymentPage.fillCustomerDetails(liveSalesPage);
    await paymentPage.completeStripePayment(liveSalesPage);
    await paymentPage.acceptUpsell(liveSalesPage);
    await paymentPage.verifyFinalPage(liveSalesPage);
  } finally {
    await liveSalesPage.close().catch(() => {});
  }

  Logger.info('FINISH', '🎉 Full Product Flow, Funnel Tree, and Purchase Verified!');
});