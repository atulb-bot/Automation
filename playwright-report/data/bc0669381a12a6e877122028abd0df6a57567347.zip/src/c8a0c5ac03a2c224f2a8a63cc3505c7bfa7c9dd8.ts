import { Page, expect } from '@playwright/test';
import { Logger } from '../utils/logger';
import { PopupHandler } from '../utils/popup-handler';
import { TestContext } from '../utils/test-context';

export class LoginPage {
  constructor(private page: Page, private context: TestContext) {}

  public async openLogin(): Promise<void> {
    this.context.recordStep('Navigate to Login');
    Logger.info('LOGIN', 'Opening FlexiFunnels login page...');
    
    await this.page.goto('/login', { waitUntil: 'domcontentloaded' });
    await this.page.waitForLoadState('domcontentloaded');

    // Dismiss any initial cookie or popup that shows up immediately
    await PopupHandler.dismissKnownPopups(this.page);
  }

  public async login(email: string, pass: string): Promise<void> {
    this.context.recordStep('Perform Login');
    Logger.info('LOGIN', 'Entering login credentials...');

    // 1. Enter Email ID (matches recorded script)
    const emailInput = this.page.getByRole('textbox', { name: 'Email ID' });
    await expect(emailInput).toBeVisible({ timeout: 20000 });
    await emailInput.click();
    await emailInput.fill(email);

    // 2. Enter Password (matches recorded script)
    const passInput = this.page.getByRole('textbox', { name: 'Password' });
    await expect(passInput).toBeVisible({ timeout: 15000 });
    await passInput.click();
    await passInput.fill(pass);

    // 3. Remember Me Checkbox
    const rememberMeText = this.page.getByText('Remember me');
    if (await rememberMeText.isVisible({ timeout: 2000 }).catch(() => false)) {
      await rememberMeText.click().catch(() => {});
      const rememberCheckbox = this.page.getByRole('checkbox', { name: 'Remember me' });
      await rememberCheckbox.check().catch(() => {});
    }

    // Dismiss cookie banner or chat overlay if sitting over the button
    await PopupHandler.dismissKnownPopups(this.page);
    await PopupHandler.clearBlockingOverlays(this.page);

    // 4. Click "Login Now"
    const loginBtn = this.page.getByRole('button', { name: 'Login Now' });
    await expect(loginBtn).toBeVisible({ timeout: 10000 });
    await expect(loginBtn).toBeEnabled({ timeout: 10000 });
    await loginBtn.click();
    Logger.info('LOGIN', 'Clicked "Login Now", waiting for dashboard transition...');

    // 5. Handle post-click popups immediately
    await PopupHandler.dismissKnownPopups(this.page);

    // Check for "Accept All" cookie banner right after login attempt
    const acceptAllBtn = this.page.getByRole('button', { name: 'Accept All' });
    if (await acceptAllBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
      await acceptAllBtn.click().catch(() => {});
      Logger.info('LOGIN', 'Accepted cookies post-login');
    }

    // 6. Verify successful login by waiting for dashboard/Projects navigation link
    try {
      const projectsLink = this.page.getByRole('link', { name: 'Projects' });
      await expect(projectsLink).toBeVisible({ timeout: 35000 });
      Logger.info('LOGIN', 'Login successful! Verified Projects navigation.');
      this.context.recordStep('Login Completed');
    } catch {
      // If still on login page, re-attempt dismiss and report
      await PopupHandler.dismissKnownPopups(this.page);
      const url = this.page.url();
      if (url.includes('/login')) {
        Logger.error('LOGIN', 'LOGIN FAILED: Still on login page. Check credentials or CAPTCHA presence.');
        throw new Error('LOGIN FAILED: Could not reach authenticated dashboard state.');
      }
    }
  }
}